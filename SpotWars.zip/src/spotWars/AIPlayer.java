package spotWars;

public interface AIPlayer {
	public void makeMoves();
}
